/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#1 SMP PREEMPT Wed Aug 27 07:20:50 UTC 2025"
#define LINUX_COMPILE_BY "oe-user"
#define LINUX_COMPILE_HOST "oe-host"
#define LINUX_COMPILER "gcc version 9.2.0 (GCC)"
